<?php 

$full_name = $_POST['firstName'] . " " .  $_POST['lastName'];
$email = $_POST['email'];
$password = $_POST['password'];
$city = $_POST['city'];
$user_id = rand(0,999999999);
$num_races = 0;


$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "project2";
$conn = mysqli_connect($dbhost, $dbuser, $dbpassword, $dbname) or die("Connection failed");

// echo "hello $full_name";


while(true){
    $check_user_exists = "SELECT * 
                    FROM `users` h
                    WHERE h.`Id` = $user_id";

    $result_table = mysqli_query($conn, $check_user_exists);

    if( mysqli_fetch_array($result_table) === null ) {
        // if it does not return an sql object then insert the value && count(mysqli_fetch_array($table_of_friends)) !== 1
        echo "you are adding $full_name to $user_id";

        $add_user_sql = "INSERT INTO `users` VALUES ($user_id, '$full_name', $num_races, '$city', '$email', '$password')";
        if(mysqli_query($conn, $add_user_sql)){
            echo "it worked!";
        }
        else{
            echo "it did not work";
            echo $add_user_sql;
        }
        break;
    }
    else {
        echo "This user is already exists.";
        $user_id = rand(0,999999999);
        // try another random userid to make sure unique.

        break;
    }
}


mysqli_close($conn);
?>