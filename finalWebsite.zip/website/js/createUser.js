// Creator: Ted Nesham
// Date Created: 04/28/2020


const createUser = () => {

    const firstName = document.getElementById("firstName").value;
    const lastName = document.getElementById("lastName").value;
    const password = document.getElementById("password1").value;
    const checkPassword = document.getElementById("password2").value;
    const email = document.getElementById("email").value;
    const city = document.getElementById("city").value;
   

    
    if (password === checkPassword) {

        let http = new XMLHttpRequest();
        http.open("POST", "../php/greetNewUser.php", true);
        http.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        let params = "firstName=" + firstName + "&lastName=" + lastName + "&email=" + email + "&password=" + password + "&city=" + city; 
        console.log(params);
        http.send(params);
        setTimeout(() => {
            postForm(document.getElementById("signUpForm"));
            
        }, 3000); 
        http.onload = () => {
            alert(http.responseText);
        }


    } else {
        alert("please make sure your passwords match");
    }

}

const postForm = (form) => {
    form.submit();
}