<?php

if ( isset( $_POST['submit'] ) ) { // check if the email and password exist in the database.
   header("Location: ../index.php"); 
}

?>
<!DOCTYPE html>
<head>
   <meta charset="utf-8">
   <title>Login Page</title>
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link href="../css/signup.css" rel="stylesheet">
   <script type="text/javascript" src="../js/createUser.js"></script>
</head>
<body class="text-center">
   <!DOCTYPE html>
   <html lang="en">
      <head>
         <meta charset="utf-8">
         <meta name="description" content="This Is a page practice about HTML 5 inputs & forms">
         <title>Input & Forms</title>
      </head>

      <main>
         <div class="loginBox">
         <img   style="margin-left:50%; margin: 0; width: 200px;" src="https://149373412.v2.pressablecdn.com/wp-content/uploads/2019/03/stateICONS-MISSOURI.png" >
         <h1 style=" color:white; font-family: Impact, Charcoal, sans-serif; margin: 0;">MO Racin'</h1>
         <br>
            <h2>Sign Up</h2>
            <form id="signUpForm" method="post">
               <p>First Name</p>
               <input type="text" id="firstName" placeholder="First Name">
               <p>Last Name</p>
               <input type="text" id="lastName" placeholder="Last Name">
               <p>City</p>
               <input type="text" id="city" placeholder="city">
               <p>E-mail Address</p>
               <input type="email" id="email" placeholder="e-mail">
               <p>Password
               <p>
               <input type="password" id="password1" placeholder="Create Password">
               <p>Re-enter Password</p>
               <input type="password" id="password2" Placeholder="Confirm Password">
               <input onclick="createUser()" type="submit" name="submit" value="Create Account">
               <p>Already have an account? <a href="../index.php">Sign In</a></p>
            </form>
         </div>
      </main>
      </body>
   </html>