 //document.location.href ="st_louis.php?cityValue"+"St Louis";
 
 let citySelector = document.getElementById("citySelector");

 var citys = ["St. Louis", "Kansas City", "Springfield", "Independence", "Columbia"];
 var i;
 var option;
 
 for (i = 0; i < citys.length; i++) {
    option = document.createElement("option");
     option.text = citys[i] ;
    citySelector.add(option);
 }
 //************************************************************	  
 let date = new Date().getFullYear();
  let yearSelector = document.getElementById("yearSelector");
  for (let i = date; i <= date+5; i++) {
         option = document.createElement("option");
         option.text = i ;
         yearSelector.add(option);
     }
     
 //************************************************************	
  let monthSelector = document.getElementById("monthSelector");
 var months = ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];
    
    for (i = 0; i < months.length; i++) {
       option = document.createElement("option");
       option.text = months[i] ;
       monthSelector.add(option);
 } 	
    //************************************************************	
         
     let daySelector = document.getElementById("daySelector");
 
     for (let i = 1; i <= 31; i++) {
         option = document.createElement("option");
         option.text = i ;
         daySelector.add(option);
     }
    //********************************************************** 