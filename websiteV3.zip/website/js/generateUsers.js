/********************************************************************
 * Date Created: 04/07/2020
 * Creator: Theodore Nesham
 * Version: 1.0
 * Last Modified: 04/21/2020
 *******************************************************************/

 // We are making the assumtion that there are roughly 100 races.

import cityJson from './cities.js';

const databaseObj = []
// the main object array that will hold race results, users, and events just so we can load mass amounts of data.



const userList = () => {
    let userObj = [];
    (() => {
         // making var so that function scoping is involved.
        let cities = Object.keys(cityJson); // returns an array of keys
        let emailExt = ["gmail.com", "hotmail.com", "live.com", "outlook.com", "mail.com", "yahoo.com"];
        let symbolList = ["\!", "@", "\%", "\_", "$", "\*"];
        let firstNames = ["Liam", "Noah", "William", "James", "Oliver", "Benjamin", "Elijah", "Lucas", "Mason", "Logan", "Alexander",
            "Emma", "Olivia", "Ava", "Isabella", "Sophia", "Charlotte", "Mia", "Amelia", "Harper", "Evelyn"];
        let lastNames = ["Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson", "Moore", "Taylor", "Anderson",
            "Clark", "Rodriguez", "Lewis", "Lee", "Walker", "Hall", "Allen", "Young", "Hernandez", "King", "Wright",
            "Thomas", "Jackson", "White", "Harris", "Martin", "Thompson", "Garcia", "Martinez", "Robinson", "Lopez", "Hill",
            "Scott", "Green", "Adams", "Baker", "Gonzalez", "Nelson", "Carter", "Mitchell", "Perez", "Roberts", "Turner",
            "Phillips", "Campbell", "Parker", "Evans", "Edwards", "Collins"];

        // generate random data for the user's record.
        // random data is unique combinations of the above arrays.
        for (let i = 0; i < 200; i++) {
            let fullName = firstNames[Math.floor(Math.random() * firstNames.length)] + " " + lastNames[Math.floor(Math.random() * lastNames.length)];
            let userId = Math.round(Math.random() * Math.pow(10, 9)); // will be at max 9 digits long.
            let numRaces = Math.floor(( (i > 175 ? (Math.random() * 10000 ) : (Math.random() * i * 10)) / 100 )) ;
            let city = cities[Math.floor(Math.random() * cities.length)];
            let email = fullName.replace(" ", "@") + emailExt[Math.floor(Math.random() * emailExt.length)];
            let userPassword = fullName.replace(" ", symbolList[Math.floor(Math.random() * symbolList.length)]) + symbolList[Math.floor(Math.random() * symbolList.length)];

            while (userObj.hasOwnProperty(userId)) { // loop until the uerId is not a duplicate.
                userId = Math.round(Math.random() * Math.pow(10, 9))
            }
            // push the new user object into the main userObj
            userObj.push({
                Id: userId,
                FullName: fullName,
                City: city,
                Email: email,
                UserPass: userPassword,
                NumRaces:numRaces
            });
        }
    })();
    return userObj;
}




const raceList = () => {
    let raceObj = [];
    (() => {
         // making var so that function scoping is involved.
        let cities = Object.keys(cityJson); // returns an array of keys
        let event_names = ["go", "Foam_Glow", "Stadium_Blitz", "Frisco_Railroad_Run"];
        let distance = ["5K", "10K", "15K", "20K", "Half-marathon", "25K", "30K", "Marathon" ];


        let randomYear =  ~~(Math.random() * (2020 - 2000) + 2000);
        let randomMonth =  ~~(Math.random() * (12 - 1) + 1);
        let randomDay =  ~~(Math.random() * (30 - 1) + 1);
      
        let date2 = new Date(randomYear, randomMonth, randomDay);

        // generate random data for the user's record.
        // random data is unique combinations of the above arrays.
        for (let i = 0; i < 200; i++) {
            let eventName = event_names[Math.floor(Math.random() * event_names.length)]
                            +  "_" + cities[Math.floor(Math.random() * cities.length)].replace(" ", "")
                            + "_" + distance[Math.floor(Math.random() * distance.length)];

            let date = new Date( start + Math.random() * (2020 - 2000));
            let hour = startHour + Math.random() * (endHour - startHour) | 0;
            date.setHours(hour);


            console.log(eventName);

            // let userId = Math.round(Math.random() * Math.pow(10, 9)); // will be at max 9 digits long.
            // let numRaces = Math.floor(( (i > 175 ? (Math.random() * 10000 ) : (Math.random() * i * 10)) / 100 )) ;
            // let city = cities[Math.floor(Math.random() * cities.length)];
            // let email = fullName.replace(" ", "@") + emailExt[Math.floor(Math.random() * emailExt.length)];
            // let userPassword = fullName.replace(" ", symbolList[Math.floor(Math.random() * symbolList.length)]) + symbolList[Math.floor(Math.random() * symbolList.length)];

            // while (userObj.hasOwnProperty(userId)) { // loop until the uerId is not a duplicate.
            //     userId = Math.round(Math.random() * Math.pow(10, 9))
            // }
            // push the new user object into the main userObj
            // userObj.push({
            //     Id: userId,
            //     FullName: fullName,
            //     City: city,
            //     Email: email,
            //     UserPass: userPassword,
            //     NumRaces:numRaces
            // });
        }
    })();
    return userObj;
}



databaseObj.users = userList();
databaseObj.races = raceList();
console.log(databaseObj);


document.getElementById("textArea").value = JSON.stringify(userList());
// document.getElementById("myJsonForm").submit();
// fill and submit the form with the json object.



