<?php 
$table_index = intval(filter_input(INPUT_GET, "table_index"));

// might be useful to know who is viewing the race so they don't see races they already signed up for
$user_id = intval(filter_input(INPUT_GET, "userId"));
$city_value= intval(filter_input(INPUT_GET, "cityValue"));


// echo "city value:"+$city_value;


$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "project2";
$conn = mysqli_connect($dbhost, $dbuser, $dbpassword, $dbname) or die("Connection failed");
// connection to the database.


$json_file = "../js/cities.json";
$city_json = file_get_contents($json_file);
$cities = json_decode($city_json);
// getting all of the city data, key for CITIES is 'city':'../php/events.php?city="cityname"

$tblArr = array();

// ***ADDED  event table here******* 
$tblArr[] = "event";


$user_sql = "SELECT *
                                FROM   `has_friends`
                                WHERE `user_id` = $user_id";

$user_friends_table = mysqli_query($conn, $user_sql);

while ($row = mysqli_fetch_array($user_friends_table)) { 
    $rows[] = $row;

}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>MO Racin' <?php echo $_GET["username"] ?> </title>

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="../css/user_home.css">
    <link rel="stylesheet" href="../css/main_styles.css">
    
    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.3/dist/Chart.min.js" integrity="sha256-R4pqcOYV8lt7snxMQO/HSbVCFRPMdrhAFMH+vr9giYI=" crossorigin="anonymous"></script>
    <!-- <script src="../js/stlouis.js"> </script> -->
 <!-- <script src="../js/stlouis.js"> </script> -->


</head>

<body> 
    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
            <img  src="https://149373412.v2.pressablecdn.com/wp-content/uploads/2019/03/stateICONS-MISSOURI.png" style="padding:0;" width="100" height="100">
            <h3 style="font-family: Impact, Charcoal, sans-serif;">MO Racin'</h3>
            </div>

            <ul class="list-unstyled components">
                <p style="font-weight: bold;">🏃‍♂️ <?php echo $_GET["username"] ?> 🏃‍♂️</p> 
                <!-- Fill with the actual username. -->
                
                <li>
                    <a href='<?php echo  "./user_home.php?id= " . $_GET['userId'] . "&username="  . $_GET['username']  . "&table_index=0"  ?>' >My profile</a>
                </li>
        </nav>

        <!-- Page Content  -->
        <div id="content">
            <h2 style="margin-left: 5%;">Your frineds list:</h2>


            <table class="table table-light">
            <thead style="background-color: #93C47D;">
                <!-- DISPLAYING THE COLUMN HEADERS -->
                <tr>
                <td class='header-td'><strong>Friend name</strong></td>
                <td class='header-td'><strong>Number of races</strong></td>
                <td class='header-td'><strong>Friend's City</strong></td>
                </tr>
            </thead>
            <tbody>
                <?php for ($i = 0; isset($rows) && $i < count($rows); $i++) { ?>
                    <!-- LOOP OVER ALL OF THE ROWS FROM THE DATABASE -->
                    <tr class="rows">

                    <?php 
                            // get all the friend data here!
                            $get_friend_sql = "SELECT `Name`, `Num_races`, `city`
                                FROM   `users`
                                WHERE `id` = " . $rows[$i][1];
                               

                            $friend = mysqli_query($conn, $get_friend_sql);

                            while ($row = mysqli_fetch_array($friend)) { 
                                $rows[$i][1] = $row;
                            }
                            ?>


                        <?php for ($j=0; isset($rows) && $j < count($rows[$i][1]) / 2 ; $j++) { ?>
                            <!-- ECHO OUT ALL OF THE COLUMN VALUES IN EACH ROW -->
                            <td>
                            
                            <?php echo $rows[$i][1][$j] ?>
                            </td>
                            
                        <?php } ?>
                    </tr>
                    <?php } ?>
                
                </tbody>
            </table>


            </div> <!-- close id content-->
        </div> <!-- close wrapper>-->
      
    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

    <script type="text/javascript" src="../js/sidebar.js"></script>
    <!-- FOR the sidebar toggle -->
</body>

</html>
